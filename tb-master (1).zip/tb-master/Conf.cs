﻿namespace Tieba
{
    class Conf
    {
        public const string APP_URL= "http://c.tieba.baidu.com";

        public const string HTTP_URL = "http://tieba.baidu.com";

        public const string UPDATE_URL = "http://snowed.applinzi.com";

        public const string strtime = "20220405";


    }
}
