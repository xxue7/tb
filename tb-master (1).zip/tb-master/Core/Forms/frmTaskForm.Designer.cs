﻿namespace Tieba
{
    partial class TaskForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.linkLabel6 = new System.Windows.Forms.LinkLabel();
            this.linkLabel4 = new System.Windows.Forms.LinkLabel();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.mangertb = new System.Windows.Forms.ComboBox();
            this.button1 = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.txtscday = new System.Windows.Forms.TextBox();
            this.ckdct = new System.Windows.Forms.CheckBox();
            this.label5 = new System.Windows.Forms.Label();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.numericUpDown2 = new System.Windows.Forms.NumericUpDown();
            this.linkLabel7 = new System.Windows.Forms.LinkLabel();
            this.label11 = new System.Windows.Forms.Label();
            this.ckimg = new System.Windows.Forms.CheckBox();
            this.button10 = new System.Windows.Forms.Button();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.label10 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.linkLabel8 = new System.Windows.Forms.LinkLabel();
            this.label1 = new System.Windows.Forms.Label();
            this.button13 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.txtsetContent = new System.Windows.Forms.TextBox();
            this.listView3 = new System.Windows.Forms.ListView();
            this.columnHeader14 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader15 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader16 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader17 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.修改选中ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.删除选中ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.清空ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.checkBox7 = new System.Windows.Forms.CheckBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.ckintro = new System.Windows.Forms.CheckBox();
            this.cklz = new System.Windows.Forms.CheckBox();
            this.ckblackname = new System.Windows.Forms.CheckBox();
            this.ckpostnum = new System.Windows.Forms.CheckBox();
            this.txtpostnum = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtpn = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtreason = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.linkLabel2 = new System.Windows.Forms.LinkLabel();
            this.cklevel = new System.Windows.Forms.CheckBox();
            this.txtlevel = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtblockday = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.ckblock = new System.Windows.Forms.CheckBox();
            this.ckdel = new System.Windows.Forms.CheckBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.button9 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.listView1 = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader18 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.labAssistant = new System.Windows.Forms.Label();
            this.labManger = new System.Windows.Forms.Label();
            this.labPrivate = new System.Windows.Forms.Label();
            this.labPostNum = new System.Windows.Forms.Label();
            this.labAge = new System.Windows.Forms.Label();
            this.labUid = new System.Windows.Forms.Label();
            this.labSwitchImTime = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.button8 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.linkLabel9 = new System.Windows.Forms.LinkLabel();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox5.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(743, 327);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.checkBox6);
            this.tabPage1.Controls.Add(this.linkLabel6);
            this.tabPage1.Controls.Add(this.linkLabel4);
            this.tabPage1.Controls.Add(this.richTextBox1);
            this.tabPage1.Controls.Add(this.button2);
            this.tabPage1.Controls.Add(this.mangertb);
            this.tabPage1.Controls.Add(this.button1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(735, 301);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "操作";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // checkBox6
            // 
            this.checkBox6.AutoSize = true;
            this.checkBox6.Location = new System.Drawing.Point(657, 6);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(72, 16);
            this.checkBox6.TabIndex = 9;
            this.checkBox6.Text = "详细信息";
            this.checkBox6.UseVisualStyleBackColor = true;
            this.checkBox6.CheckedChanged += new System.EventHandler(this.checkBox6_CheckedChanged);
            // 
            // linkLabel6
            // 
            this.linkLabel6.AutoSize = true;
            this.linkLabel6.Location = new System.Drawing.Point(6, 3);
            this.linkLabel6.Name = "linkLabel6";
            this.linkLabel6.Size = new System.Drawing.Size(53, 12);
            this.linkLabel6.TabIndex = 7;
            this.linkLabel6.TabStop = true;
            this.linkLabel6.Text = "垃圾回收";
            this.linkLabel6.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel6_LinkClicked);
            // 
            // linkLabel4
            // 
            this.linkLabel4.AutoSize = true;
            this.linkLabel4.Location = new System.Drawing.Point(125, 26);
            this.linkLabel4.Name = "linkLabel4";
            this.linkLabel4.Size = new System.Drawing.Size(65, 12);
            this.linkLabel4.TabIndex = 6;
            this.linkLabel4.TabStop = true;
            this.linkLabel4.Text = "管理的贴吧";
            this.linkLabel4.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel4_LinkClicked);
            // 
            // richTextBox1
            // 
            this.richTextBox1.BackColor = System.Drawing.SystemColors.MenuBar;
            this.richTextBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.richTextBox1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.richTextBox1.Location = new System.Drawing.Point(3, 72);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical;
            this.richTextBox1.Size = new System.Drawing.Size(729, 226);
            this.richTextBox1.TabIndex = 4;
            this.richTextBox1.Text = "";
            // 
            // button2
            // 
            this.button2.Enabled = false;
            this.button2.Location = new System.Drawing.Point(461, 16);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(54, 32);
            this.button2.TabIndex = 3;
            this.button2.Text = "暂停";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // mangertb
            // 
            this.mangertb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.mangertb.FormattingEnabled = true;
            this.mangertb.Location = new System.Drawing.Point(196, 21);
            this.mangertb.Name = "mangertb";
            this.mangertb.Size = new System.Drawing.Size(145, 20);
            this.mangertb.TabIndex = 2;
            this.mangertb.SelectedIndexChanged += new System.EventHandler(this.mangertb_SelectedIndexChanged);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(373, 16);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(63, 32);
            this.button1.TabIndex = 0;
            this.button1.Text = "启动";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox8);
            this.tabPage2.Controls.Add(this.groupBox3);
            this.tabPage2.Controls.Add(this.groupBox1);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(735, 301);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "设置";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.txtscday);
            this.groupBox8.Controls.Add(this.ckdct);
            this.groupBox8.Controls.Add(this.label5);
            this.groupBox8.Controls.Add(this.linkLabel1);
            this.groupBox8.Controls.Add(this.numericUpDown2);
            this.groupBox8.Controls.Add(this.linkLabel7);
            this.groupBox8.Controls.Add(this.label11);
            this.groupBox8.Controls.Add(this.ckimg);
            this.groupBox8.Controls.Add(this.button10);
            this.groupBox8.Controls.Add(this.numericUpDown1);
            this.groupBox8.Controls.Add(this.label10);
            this.groupBox8.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.groupBox8.Location = new System.Drawing.Point(3, 257);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(729, 41);
            this.groupBox8.TabIndex = 6;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "附加设置";
            // 
            // txtscday
            // 
            this.txtscday.Location = new System.Drawing.Point(194, 14);
            this.txtscday.Name = "txtscday";
            this.txtscday.Size = new System.Drawing.Size(59, 21);
            this.txtscday.TabIndex = 1;
            this.txtscday.Text = "100";
            this.txtscday.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textNumber);
            // 
            // ckdct
            // 
            this.ckdct.AutoSize = true;
            this.ckdct.Location = new System.Drawing.Point(363, 17);
            this.ckdct.Name = "ckdct";
            this.ckdct.Size = new System.Drawing.Size(42, 16);
            this.ckdct.TabIndex = 11;
            this.ckdct.Text = "DCT";
            this.ckdct.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(135, 17);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 12);
            this.label5.TabIndex = 0;
            this.label5.Text = "扫描间隔";
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Location = new System.Drawing.Point(588, 19);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(53, 12);
            this.linkLabel1.TabIndex = 4;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "正则测试";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // numericUpDown2
            // 
            this.numericUpDown2.Location = new System.Drawing.Point(457, 15);
            this.numericUpDown2.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numericUpDown2.Name = "numericUpDown2";
            this.numericUpDown2.Size = new System.Drawing.Size(42, 21);
            this.numericUpDown2.TabIndex = 10;
            this.numericUpDown2.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.numericUpDown2.ValueChanged += new System.EventHandler(this.numericUpDown2_ValueChanged);
            // 
            // linkLabel7
            // 
            this.linkLabel7.AutoSize = true;
            this.linkLabel7.Location = new System.Drawing.Point(668, 19);
            this.linkLabel7.Name = "linkLabel7";
            this.linkLabel7.Size = new System.Drawing.Size(53, 12);
            this.linkLabel7.TabIndex = 5;
            this.linkLabel7.TabStop = true;
            this.linkLabel7.Text = "图片测试";
            this.linkLabel7.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel7_LinkClicked_1);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(416, 19);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(35, 12);
            this.label11.TabIndex = 9;
            this.label11.Text = "汉明:";
            // 
            // ckimg
            // 
            this.ckimg.AutoSize = true;
            this.ckimg.Location = new System.Drawing.Point(274, 17);
            this.ckimg.Name = "ckimg";
            this.ckimg.Size = new System.Drawing.Size(72, 16);
            this.ckimg.TabIndex = 0;
            this.ckimg.Text = "启用图片";
            this.ckimg.UseVisualStyleBackColor = true;
            this.ckimg.Click += new System.EventHandler(this.ckimg_Click);
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(505, 14);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(56, 23);
            this.button10.TabIndex = 8;
            this.button10.Text = "更新";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(73, 12);
            this.numericUpDown1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(39, 21);
            this.numericUpDown1.TabIndex = 7;
            this.numericUpDown1.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(6, 17);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(59, 12);
            this.label10.TabIndex = 6;
            this.label10.Text = "扫描线程:";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.linkLabel8);
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Controls.Add(this.button13);
            this.groupBox3.Controls.Add(this.button12);
            this.groupBox3.Controls.Add(this.label22);
            this.groupBox3.Controls.Add(this.label21);
            this.groupBox3.Controls.Add(this.label12);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.comboBox3);
            this.groupBox3.Controls.Add(this.comboBox2);
            this.groupBox3.Controls.Add(this.comboBox1);
            this.groupBox3.Controls.Add(this.txtsetContent);
            this.groupBox3.Controls.Add(this.listView3);
            this.groupBox3.Location = new System.Drawing.Point(290, 7);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(440, 244);
            this.groupBox3.TabIndex = 5;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "内容设置";
            // 
            // linkLabel8
            // 
            this.linkLabel8.AutoSize = true;
            this.linkLabel8.Location = new System.Drawing.Point(91, 203);
            this.linkLabel8.Name = "linkLabel8";
            this.linkLabel8.Size = new System.Drawing.Size(137, 12);
            this.linkLabel8.TabIndex = 32;
            this.linkLabel8.TabStop = true;
            this.linkLabel8.Text = "一键添加白名单吧务团队";
            this.linkLabel8.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel8_LinkClicked);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(111, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(311, 12);
            this.label1.TabIndex = 31;
            this.label1.Text = "右键可执行相关修改，手动确认只限关键词,黑名单直接删";
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(343, 196);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(75, 24);
            this.button13.TabIndex = 30;
            this.button13.Text = "删除";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(258, 197);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(79, 24);
            this.button12.TabIndex = 29;
            this.button12.Text = "添加";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click_1);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(393, 143);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(41, 12);
            this.label22.TabIndex = 28;
            this.label22.Text = "手动：";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(341, 143);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(41, 12);
            this.label21.TabIndex = 27;
            this.label21.Text = "正则：";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(256, 143);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(41, 12);
            this.label12.TabIndex = 26;
            this.label12.Text = "类型：";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(4, 145);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 12);
            this.label4.TabIndex = 25;
            this.label4.Text = "内容：";
            // 
            // comboBox3
            // 
            this.comboBox3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Items.AddRange(new object[] {
            "是",
            "否"});
            this.comboBox3.Location = new System.Drawing.Point(395, 158);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(39, 20);
            this.comboBox3.TabIndex = 24;
            // 
            // comboBox2
            // 
            this.comboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "是",
            "否"});
            this.comboBox2.Location = new System.Drawing.Point(343, 158);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(46, 20);
            this.comboBox2.TabIndex = 23;
            // 
            // comboBox1
            // 
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "回复关键词",
            "标题关键词",
            "白名单",
            "黑名单",
            "信任内容"});
            this.comboBox1.Location = new System.Drawing.Point(258, 158);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(79, 20);
            this.comboBox1.TabIndex = 22;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // txtsetContent
            // 
            this.txtsetContent.Location = new System.Drawing.Point(6, 160);
            this.txtsetContent.Name = "txtsetContent";
            this.txtsetContent.Size = new System.Drawing.Size(246, 21);
            this.txtsetContent.TabIndex = 21;
            // 
            // listView3
            // 
            this.listView3.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader14,
            this.columnHeader15,
            this.columnHeader16,
            this.columnHeader17});
            this.listView3.ContextMenuStrip = this.contextMenuStrip1;
            this.listView3.Dock = System.Windows.Forms.DockStyle.Top;
            this.listView3.FullRowSelect = true;
            this.listView3.Location = new System.Drawing.Point(3, 17);
            this.listView3.MultiSelect = false;
            this.listView3.Name = "listView3";
            this.listView3.Size = new System.Drawing.Size(434, 123);
            this.listView3.TabIndex = 20;
            this.listView3.UseCompatibleStateImageBehavior = false;
            this.listView3.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader14
            // 
            this.columnHeader14.Text = "内容";
            this.columnHeader14.Width = 248;
            // 
            // columnHeader15
            // 
            this.columnHeader15.Text = "类型";
            this.columnHeader15.Width = 57;
            // 
            // columnHeader16
            // 
            this.columnHeader16.Text = "正则";
            this.columnHeader16.Width = 46;
            // 
            // columnHeader17
            // 
            this.columnHeader17.Text = "手动";
            this.columnHeader17.Width = 40;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.修改选中ToolStripMenuItem,
            this.删除选中ToolStripMenuItem,
            this.清空ToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(125, 70);
            // 
            // 修改选中ToolStripMenuItem
            // 
            this.修改选中ToolStripMenuItem.Name = "修改选中ToolStripMenuItem";
            this.修改选中ToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.修改选中ToolStripMenuItem.Text = "修改选中";
            this.修改选中ToolStripMenuItem.Click += new System.EventHandler(this.修改选中ToolStripMenuItem_Click);
            // 
            // 删除选中ToolStripMenuItem
            // 
            this.删除选中ToolStripMenuItem.Name = "删除选中ToolStripMenuItem";
            this.删除选中ToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.删除选中ToolStripMenuItem.Text = "删除选中";
            this.删除选中ToolStripMenuItem.Click += new System.EventHandler(this.删除选中ToolStripMenuItem_Click);
            // 
            // 清空ToolStripMenuItem
            // 
            this.清空ToolStripMenuItem.Name = "清空ToolStripMenuItem";
            this.清空ToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.清空ToolStripMenuItem.Text = "清空";
            this.清空ToolStripMenuItem.Click += new System.EventHandler(this.清空ToolStripMenuItem_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.checkBox7);
            this.groupBox1.Controls.Add(this.dateTimePicker1);
            this.groupBox1.Controls.Add(this.ckintro);
            this.groupBox1.Controls.Add(this.cklz);
            this.groupBox1.Controls.Add(this.ckblackname);
            this.groupBox1.Controls.Add(this.ckpostnum);
            this.groupBox1.Controls.Add(this.txtpostnum);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.txtpn);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.txtreason);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.linkLabel2);
            this.groupBox1.Controls.Add(this.cklevel);
            this.groupBox1.Controls.Add(this.txtlevel);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txtblockday);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.ckblock);
            this.groupBox1.Controls.Add(this.ckdel);
            this.groupBox1.Location = new System.Drawing.Point(6, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(278, 245);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "设置1";
            // 
            // checkBox7
            // 
            this.checkBox7.AutoSize = true;
            this.checkBox7.ForeColor = System.Drawing.Color.MediumBlue;
            this.checkBox7.Location = new System.Drawing.Point(191, 191);
            this.checkBox7.Name = "checkBox7";
            this.checkBox7.Size = new System.Drawing.Size(72, 16);
            this.checkBox7.TabIndex = 30;
            this.checkBox7.Text = "启用时间";
            this.checkBox7.UseVisualStyleBackColor = true;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker1.Location = new System.Drawing.Point(22, 191);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(154, 21);
            this.dateTimePicker1.TabIndex = 29;
            // 
            // ckintro
            // 
            this.ckintro.AutoSize = true;
            this.ckintro.ForeColor = System.Drawing.Color.MediumBlue;
            this.ckintro.Location = new System.Drawing.Point(191, 18);
            this.ckintro.Name = "ckintro";
            this.ckintro.Size = new System.Drawing.Size(72, 16);
            this.ckintro.TabIndex = 28;
            this.ckintro.Text = "检查简介";
            this.ckintro.UseVisualStyleBackColor = true;
            // 
            // cklz
            // 
            this.cklz.AutoSize = true;
            this.cklz.ForeColor = System.Drawing.Color.Blue;
            this.cklz.Location = new System.Drawing.Point(26, 39);
            this.cklz.Name = "cklz";
            this.cklz.Size = new System.Drawing.Size(150, 16);
            this.cklz.TabIndex = 27;
            this.cklz.Text = "违规用户=楼主(删主题)";
            this.cklz.UseVisualStyleBackColor = true;
            // 
            // ckblackname
            // 
            this.ckblackname.AutoSize = true;
            this.ckblackname.Location = new System.Drawing.Point(137, 18);
            this.ckblackname.Name = "ckblackname";
            this.ckblackname.Size = new System.Drawing.Size(48, 16);
            this.ckblackname.TabIndex = 24;
            this.ckblackname.Text = "拉黑";
            this.ckblackname.UseVisualStyleBackColor = true;
            // 
            // ckpostnum
            // 
            this.ckpostnum.AutoSize = true;
            this.ckpostnum.ForeColor = System.Drawing.Color.MediumBlue;
            this.ckpostnum.Location = new System.Drawing.Point(137, 166);
            this.ckpostnum.Name = "ckpostnum";
            this.ckpostnum.Size = new System.Drawing.Size(72, 16);
            this.ckpostnum.TabIndex = 23;
            this.ckpostnum.Text = "发帖数量";
            this.ckpostnum.UseVisualStyleBackColor = true;
            this.ckpostnum.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // txtpostnum
            // 
            this.txtpostnum.Enabled = false;
            this.txtpostnum.ImeMode = System.Windows.Forms.ImeMode.Alpha;
            this.txtpostnum.Location = new System.Drawing.Point(79, 164);
            this.txtpostnum.MaxLength = 100;
            this.txtpostnum.Name = "txtpostnum";
            this.txtpostnum.ShortcutsEnabled = false;
            this.txtpostnum.Size = new System.Drawing.Size(42, 21);
            this.txtpostnum.TabIndex = 22;
            this.txtpostnum.Text = "500";
            this.txtpostnum.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtpostnum.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textNumber);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.Color.MediumBlue;
            this.label8.Location = new System.Drawing.Point(20, 167);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(53, 12);
            this.label8.TabIndex = 21;
            this.label8.Text = "发帖数量";
            // 
            // txtpn
            // 
            this.txtpn.ImeMode = System.Windows.Forms.ImeMode.Alpha;
            this.txtpn.Location = new System.Drawing.Point(215, 65);
            this.txtpn.MaxLength = 20;
            this.txtpn.Name = "txtpn";
            this.txtpn.ShortcutsEnabled = false;
            this.txtpn.Size = new System.Drawing.Size(42, 21);
            this.txtpn.TabIndex = 17;
            this.txtpn.Text = "1";
            this.txtpn.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtpn.TextChanged += new System.EventHandler(this.txtPn_TextChanged);
            this.txtpn.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textNumber);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.Color.MediumBlue;
            this.label7.Location = new System.Drawing.Point(150, 68);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(59, 12);
            this.label7.TabIndex = 16;
            this.label7.Text = "第1和最后";
            // 
            // txtreason
            // 
            this.txtreason.Location = new System.Drawing.Point(65, 101);
            this.txtreason.Name = "txtreason";
            this.txtreason.Size = new System.Drawing.Size(206, 21);
            this.txtreason.TabIndex = 15;
            this.txtreason.Text = "封禁";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 104);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 12);
            this.label6.TabIndex = 14;
            this.label6.Text = "封禁理由";
            // 
            // linkLabel2
            // 
            this.linkLabel2.AutoSize = true;
            this.linkLabel2.Location = new System.Drawing.Point(219, 214);
            this.linkLabel2.Name = "linkLabel2";
            this.linkLabel2.Size = new System.Drawing.Size(53, 12);
            this.linkLabel2.TabIndex = 13;
            this.linkLabel2.TabStop = true;
            this.linkLabel2.Text = "保存配置";
            this.linkLabel2.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel2_LinkClicked);
            // 
            // cklevel
            // 
            this.cklevel.AutoSize = true;
            this.cklevel.Checked = true;
            this.cklevel.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cklevel.ForeColor = System.Drawing.Color.MediumBlue;
            this.cklevel.Location = new System.Drawing.Point(137, 128);
            this.cklevel.Name = "cklevel";
            this.cklevel.Size = new System.Drawing.Size(72, 16);
            this.cklevel.TabIndex = 8;
            this.cklevel.Text = "启用等级";
            this.cklevel.UseVisualStyleBackColor = true;
            this.cklevel.CheckedChanged += new System.EventHandler(this.checkBox5_CheckedChanged);
            // 
            // txtlevel
            // 
            this.txtlevel.ImeMode = System.Windows.Forms.ImeMode.Alpha;
            this.txtlevel.Location = new System.Drawing.Point(79, 126);
            this.txtlevel.MaxLength = 2;
            this.txtlevel.Name = "txtlevel";
            this.txtlevel.ShortcutsEnabled = false;
            this.txtlevel.Size = new System.Drawing.Size(42, 21);
            this.txtlevel.TabIndex = 7;
            this.txtlevel.Text = "1";
            this.txtlevel.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtlevel.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textNumber);
            this.txtlevel.Leave += new System.EventHandler(this.textBox2_Leave);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.MediumBlue;
            this.label3.Location = new System.Drawing.Point(20, 129);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 12);
            this.label3.TabIndex = 6;
            this.label3.Text = "限制等级";
            // 
            // txtblockday
            // 
            this.txtblockday.ImeMode = System.Windows.Forms.ImeMode.Alpha;
            this.txtblockday.Location = new System.Drawing.Point(81, 65);
            this.txtblockday.MaxLength = 2;
            this.txtblockday.Name = "txtblockday";
            this.txtblockday.ShortcutsEnabled = false;
            this.txtblockday.Size = new System.Drawing.Size(42, 21);
            this.txtblockday.TabIndex = 4;
            this.txtblockday.Text = "1";
            this.txtblockday.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtblockday.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textNumber);
            this.txtblockday.Leave += new System.EventHandler(this.textBox1_Leave);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(22, 68);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 12);
            this.label2.TabIndex = 3;
            this.label2.Text = "封禁天数";
            // 
            // ckblock
            // 
            this.ckblock.AutoSize = true;
            this.ckblock.Location = new System.Drawing.Point(80, 18);
            this.ckblock.Name = "ckblock";
            this.ckblock.Size = new System.Drawing.Size(48, 16);
            this.ckblock.TabIndex = 1;
            this.ckblock.Text = "封禁";
            this.ckblock.UseVisualStyleBackColor = true;
            // 
            // ckdel
            // 
            this.ckdel.AutoSize = true;
            this.ckdel.Checked = true;
            this.ckdel.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ckdel.Location = new System.Drawing.Point(26, 18);
            this.ckdel.Name = "ckdel";
            this.ckdel.Size = new System.Drawing.Size(48, 16);
            this.ckdel.TabIndex = 0;
            this.ckdel.Text = "删除";
            this.ckdel.UseVisualStyleBackColor = true;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.textBox5);
            this.tabPage3.Controls.Add(this.button9);
            this.tabPage3.Controls.Add(this.button7);
            this.tabPage3.Controls.Add(this.button6);
            this.tabPage3.Controls.Add(this.button5);
            this.tabPage3.Controls.Add(this.button4);
            this.tabPage3.Controls.Add(this.button3);
            this.tabPage3.Controls.Add(this.listView1);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(735, 301);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "日志";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(3, 168);
            this.textBox5.Multiline = true;
            this.textBox5.Name = "textBox5";
            this.textBox5.ReadOnly = true;
            this.textBox5.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox5.Size = new System.Drawing.Size(729, 99);
            this.textBox5.TabIndex = 33;
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(214, 273);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(82, 24);
            this.button9.TabIndex = 6;
            this.button9.Text = "全选";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(302, 274);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(82, 24);
            this.button7.TabIndex = 5;
            this.button7.Text = "打开选中";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(478, 274);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(82, 24);
            this.button6.TabIndex = 4;
            this.button6.Text = "清空全部";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(390, 274);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(82, 24);
            this.button5.TabIndex = 3;
            this.button5.Text = "移除选中";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button4
            // 
            this.button4.ForeColor = System.Drawing.Color.Red;
            this.button4.Location = new System.Drawing.Point(654, 274);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(67, 24);
            this.button4.TabIndex = 2;
            this.button4.Text = "封删选中";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.SelectClick);
            // 
            // button3
            // 
            this.button3.ForeColor = System.Drawing.Color.Red;
            this.button3.Location = new System.Drawing.Point(566, 274);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(82, 24);
            this.button3.TabIndex = 1;
            this.button3.Text = "删除选中";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.SelectClick);
            // 
            // listView1
            // 
            this.listView1.Activation = System.Windows.Forms.ItemActivation.OneClick;
            this.listView1.CheckBoxes = true;
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5,
            this.columnHeader6,
            this.columnHeader7,
            this.columnHeader8,
            this.columnHeader18});
            this.listView1.Dock = System.Windows.Forms.DockStyle.Top;
            this.listView1.FullRowSelect = true;
            this.listView1.LabelEdit = true;
            this.listView1.Location = new System.Drawing.Point(0, 0);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(735, 162);
            this.listView1.TabIndex = 0;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            this.listView1.SelectedIndexChanged += new System.EventHandler(this.listView1_SelectedIndexChanged);
            this.listView1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.listView1_MouseClick);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "序号";
            this.columnHeader1.Width = 36;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "作者";
            this.columnHeader2.Width = 68;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "标题";
            this.columnHeader3.Width = 170;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "tid";
            this.columnHeader4.Width = 75;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "类型";
            this.columnHeader5.Width = 90;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "结果";
            this.columnHeader6.Width = 130;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "贴吧";
            this.columnHeader7.Width = 55;
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "Fid";
            this.columnHeader8.Width = 40;
            // 
            // columnHeader18
            // 
            this.columnHeader18.Text = "uid";
            this.columnHeader18.Width = 62;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.groupBox6);
            this.tabPage4.Controls.Add(this.groupBox5);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(735, 301);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "ID信息";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.textBox8);
            this.groupBox6.Controls.Add(this.textBox7);
            this.groupBox6.Controls.Add(this.textBox6);
            this.groupBox6.Controls.Add(this.label17);
            this.groupBox6.Controls.Add(this.label23);
            this.groupBox6.Controls.Add(this.labAssistant);
            this.groupBox6.Controls.Add(this.labManger);
            this.groupBox6.Controls.Add(this.labPrivate);
            this.groupBox6.Controls.Add(this.labPostNum);
            this.groupBox6.Controls.Add(this.labAge);
            this.groupBox6.Controls.Add(this.labUid);
            this.groupBox6.Controls.Add(this.labSwitchImTime);
            this.groupBox6.Controls.Add(this.pictureBox1);
            this.groupBox6.Location = new System.Drawing.Point(137, 54);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(474, 239);
            this.groupBox6.TabIndex = 3;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "信息";
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(295, 44);
            this.textBox7.Name = "textBox7";
            this.textBox7.ReadOnly = true;
            this.textBox7.Size = new System.Drawing.Size(173, 21);
            this.textBox7.TabIndex = 23;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(156, 133);
            this.textBox6.Name = "textBox6";
            this.textBox6.ReadOnly = true;
            this.textBox6.Size = new System.Drawing.Size(312, 21);
            this.textBox6.TabIndex = 22;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label17.Location = new System.Drawing.Point(251, 20);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(47, 12);
            this.label17.TabIndex = 21;
            this.label17.Text = "用户名:";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label23.Location = new System.Drawing.Point(263, 47);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(35, 12);
            this.label23.TabIndex = 20;
            this.label23.Text = "昵称:";
            // 
            // labAssistant
            // 
            this.labAssistant.AutoSize = true;
            this.labAssistant.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.labAssistant.Location = new System.Drawing.Point(108, 214);
            this.labAssistant.Name = "labAssistant";
            this.labAssistant.Size = new System.Drawing.Size(47, 12);
            this.labAssistant.TabIndex = 19;
            this.labAssistant.Text = "小吧主:";
            // 
            // labManger
            // 
            this.labManger.AutoSize = true;
            this.labManger.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.labManger.Location = new System.Drawing.Point(115, 172);
            this.labManger.Name = "labManger";
            this.labManger.Size = new System.Drawing.Size(35, 12);
            this.labManger.TabIndex = 18;
            this.labManger.Text = "吧主:";
            // 
            // labPrivate
            // 
            this.labPrivate.AutoSize = true;
            this.labPrivate.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.labPrivate.Location = new System.Drawing.Point(115, 136);
            this.labPrivate.Name = "labPrivate";
            this.labPrivate.Size = new System.Drawing.Size(35, 12);
            this.labPrivate.TabIndex = 17;
            this.labPrivate.Text = "简介:";
            // 
            // labPostNum
            // 
            this.labPostNum.AutoSize = true;
            this.labPostNum.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.labPostNum.Location = new System.Drawing.Point(114, 108);
            this.labPostNum.Name = "labPostNum";
            this.labPostNum.Size = new System.Drawing.Size(47, 12);
            this.labPostNum.TabIndex = 13;
            this.labPostNum.Text = "发帖量:";
            // 
            // labAge
            // 
            this.labAge.AutoSize = true;
            this.labAge.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.labAge.Location = new System.Drawing.Point(115, 47);
            this.labAge.Name = "labAge";
            this.labAge.Size = new System.Drawing.Size(35, 12);
            this.labAge.TabIndex = 12;
            this.labAge.Text = "吧龄:";
            // 
            // labUid
            // 
            this.labUid.AutoSize = true;
            this.labUid.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.labUid.Location = new System.Drawing.Point(114, 20);
            this.labUid.Name = "labUid";
            this.labUid.Size = new System.Drawing.Size(29, 12);
            this.labUid.TabIndex = 11;
            this.labUid.Text = "UID:";
            // 
            // labSwitchImTime
            // 
            this.labSwitchImTime.AutoSize = true;
            this.labSwitchImTime.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.labSwitchImTime.Location = new System.Drawing.Point(239, 108);
            this.labSwitchImTime.Name = "labSwitchImTime";
            this.labSwitchImTime.Size = new System.Drawing.Size(59, 12);
            this.labSwitchImTime.TabIndex = 10;
            this.labSwitchImTime.Text = "头像更换:\r\n";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox1.Location = new System.Drawing.Point(6, 20);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(88, 90);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 9;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.button8);
            this.groupBox5.Controls.Add(this.textBox1);
            this.groupBox5.Location = new System.Drawing.Point(135, 4);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(476, 45);
            this.groupBox5.TabIndex = 2;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "ID";
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(412, 11);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(58, 27);
            this.button8.TabIndex = 0;
            this.button8.Text = "获取";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(4, 15);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(402, 21);
            this.textBox1.TabIndex = 1;
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.groupBox9);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(735, 301);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "批量";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.linkLabel9);
            this.groupBox9.Controls.Add(this.textBox2);
            this.groupBox9.Controls.Add(this.label14);
            this.groupBox9.Location = new System.Drawing.Point(122, 34);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(496, 112);
            this.groupBox9.TabIndex = 0;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "初始";
            // 
            // linkLabel9
            // 
            this.linkLabel9.AutoSize = true;
            this.linkLabel9.Location = new System.Drawing.Point(274, 46);
            this.linkLabel9.Name = "linkLabel9";
            this.linkLabel9.Size = new System.Drawing.Size(77, 12);
            this.linkLabel9.TabIndex = 12;
            this.linkLabel9.TabStop = true;
            this.linkLabel9.Text = "批量指定用户";
            this.linkLabel9.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel9_LinkClicked);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(108, 43);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(143, 21);
            this.textBox2.TabIndex = 2;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(67, 46);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(35, 12);
            this.label14.TabIndex = 1;
            this.label14.Text = "吧名:";
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(241, 71);
            this.textBox8.Name = "textBox8";
            this.textBox8.ReadOnly = true;
            this.textBox8.Size = new System.Drawing.Size(227, 21);
            this.textBox8.TabIndex = 24;
            // 
            // TaskForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(743, 327);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "TaskForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Tieba";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form2_FormClosed);
            this.Load += new System.EventHandler(this.Form2_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.contextMenuStrip1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ComboBox mangertb;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox ckblock;
        private System.Windows.Forms.CheckBox ckdel;
        private System.Windows.Forms.TextBox txtblockday;
        private System.Windows.Forms.TextBox txtlevel;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox cklevel;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.TextBox txtscday;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.LinkLabel linkLabel2;
        private System.Windows.Forms.TextBox txtreason;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.ColumnHeader columnHeader8;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.TextBox txtpn;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.LinkLabel linkLabel4;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.LinkLabel linkLabel6;
        private System.Windows.Forms.CheckBox ckpostnum;
        private System.Windows.Forms.TextBox txtpostnum;
        private System.Windows.Forms.Label label8;
        //private System.Windows.Forms.Button button11;
        private System.Windows.Forms.CheckBox ckblackname;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.CheckBox ckdct;
        private System.Windows.Forms.NumericUpDown numericUpDown2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.CheckBox ckimg;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.LinkLabel linkLabel7;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.TextBox txtsetContent;
        private System.Windows.Forms.ColumnHeader columnHeader14;
        private System.Windows.Forms.ColumnHeader columnHeader15;
        private System.Windows.Forms.ColumnHeader columnHeader16;
        private System.Windows.Forms.ColumnHeader columnHeader17;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 修改选中ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 删除选中ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 清空ToolStripMenuItem;
        public System.Windows.Forms.ListView listView3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.LinkLabel linkLabel8;
        private System.Windows.Forms.LinkLabel linkLabel9;
        private System.Windows.Forms.CheckBox cklz;
        private System.Windows.Forms.CheckBox ckintro;
        private System.Windows.Forms.ColumnHeader columnHeader18;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label labAssistant;
        private System.Windows.Forms.Label labManger;
        private System.Windows.Forms.Label labPrivate;
        private System.Windows.Forms.Label labPostNum;
        private System.Windows.Forms.Label labAge;
        private System.Windows.Forms.Label labUid;
        private System.Windows.Forms.Label labSwitchImTime;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.CheckBox checkBox7;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox8;
    }
}